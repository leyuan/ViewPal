<div class="webmaster-dashboard-container">
    <div>
        <h3><?php echo $wmname?> | Dashboard(<a href='<?php echo base_url()."index.php/webmaster/logout";?>'>log out?</a>)</h3>
        <h3>Your Merchant Id: <?php echo $mid;?></h3>
    </div>
    
</div>
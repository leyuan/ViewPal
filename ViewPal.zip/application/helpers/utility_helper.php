<?php

function public_url(){
   return base_url().'public/';
}

function dsasset_path(){
   return base_url().'public/dashboard/';
}
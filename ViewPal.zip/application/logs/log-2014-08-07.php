<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-08-07 18:48:33 --> Config Class Initialized
DEBUG - 2014-08-07 18:48:33 --> Hooks Class Initialized
DEBUG - 2014-08-07 18:48:33 --> Utf8 Class Initialized
DEBUG - 2014-08-07 18:48:33 --> UTF-8 Support Enabled
DEBUG - 2014-08-07 18:48:33 --> URI Class Initialized
DEBUG - 2014-08-07 18:48:33 --> Router Class Initialized
DEBUG - 2014-08-07 18:48:33 --> Output Class Initialized
DEBUG - 2014-08-07 18:48:33 --> Security Class Initialized
DEBUG - 2014-08-07 18:48:33 --> Input Class Initialized
DEBUG - 2014-08-07 18:48:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-07 18:48:33 --> Language Class Initialized
DEBUG - 2014-08-07 18:48:33 --> Loader Class Initialized
DEBUG - 2014-08-07 18:48:33 --> Controller Class Initialized
DEBUG - 2014-08-07 18:48:33 --> Model Class Initialized
DEBUG - 2014-08-07 18:48:33 --> Model Class Initialized
DEBUG - 2014-08-07 18:48:33 --> Database Driver Class Initialized
ERROR - 2014-08-07 18:48:33 --> 404 Page Not Found --> news/

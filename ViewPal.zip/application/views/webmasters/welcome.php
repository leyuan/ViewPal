<div class="welcome-webmaster">
    <h3> Welcome Webmaster - <?php echo $wmname?><a href="<?php echo base_url()."index.php/user/logout"?>">(Log out?)</a></h3>
    <a href='<?php echo base_url()."index.php/webmaster/dashboard?wmname=".$wmname?>'> got it, proceed to user dashboard >></a>

</div>


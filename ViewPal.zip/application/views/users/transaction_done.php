<div>
    <h3>Thanks for your payment</h3>
    <h4>Proceed to <a href="<?php echo base_url()."index.php/user/dashboard/?username=".$username;?>">your dashboard</a></h4>
</div>
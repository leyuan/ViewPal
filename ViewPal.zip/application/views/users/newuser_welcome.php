
<div class='new-user-welcome'>
    <h3> welcome </h3>
    <a href='<?php echo base_url()."index.php/user/dashboard?username=".$username?>'> got it, proceed to user dashboard >></a>
</div>
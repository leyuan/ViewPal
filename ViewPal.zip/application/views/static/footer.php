        <footer>
            <div class='static-footer'>
                <div class="container footer-container">
                    <div class='upper-footer'>
                        <div class="footer-col col-xs-12 col-sm-3 col-md-3 col-lg-3 text-left">
                            <h4>About ViewPal</h4>
                                <a href="<?php echo base_url()."index.php/features"?>">Features</a>
                                <a href="<?php echo base_url()."index.php/hiring"?>">Career</a>
                        </div>
                        <div class="footer-col col-xs-12 col-sm-3 col-md-3 col-lg-3 text-left">
                            <h4>Help & Resources</h4>
                                <a href="<?php echo base_url()."index.php/contact"?>">Contact</a>
                                <a href="<?php echo base_url()."index.php/blog"?>">Blog</a>
                        </div>
                        <div class="footer-col col-xs-12 col-sm-3 col-md-3 col-lg-3 text-left">
                            <h4>Commercial</h4>
                            <a href="<?php echo base_url()."index.php/whyviewpal"?>">Why ViewPal</a>
                                <a href="<?php echo base_url()."index.php/pricing"?>">Pricing</a>
                        </div>
                        <div class="footer-col col-xs-12 col-sm-3 col-md-3 col-lg-3 text-left footer-4">
                            <h4>Try ViewPal for free</h4>
                            <p>
                                Sign up to enter for chance to use ViewPal. Get our complementary 30-day Free Trial. 
                            </p>
                            <button class="btn footer-btn"> GET STARTED</button>
                        </div>                        
                    </div>
                </div>
                <div class='lower-footer'>
                    <div class="container copyright-container">
                        <div class="copyright">
                            <h5>&copy; 2014 ViewPal. All rights reserved. <a href=""> Terms of Use and Privacy Policy </a></h5>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </body>
</html>

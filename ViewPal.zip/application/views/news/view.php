<h1>Single Entry</h1>
<h2><?php echo $news_item['title'] ?></h2>
<div class="main">
    <?php echo $news_item['text'] ?>
</div>